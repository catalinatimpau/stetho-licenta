﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StethoWebAPI.Models
{
    public class Patient
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Number { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Sex { get; set; }
        public int Age { get; set; }
        public double Weight { get; set; }
        public double Height { get; set; }

        public string Diagnosis { get; set; }

        [Required]
        public string Username { get; set; }

        
        [NotMapped]
        public double? AdultBMI { get; set; }

        [NotMapped]
        public double? ChildWeight { get; set; }

        [NotMapped]
        public double? ChildHeight { get; set; }

        [NotMapped]
        public double BMI => Weight > 0 && Height > 0 ? Weight / Math.Pow(Height / 100.0, 2) : 0;

        [NotMapped]
        public List<string> Sounds { get; set; } = new();

        [NotMapped]
        public Dictionary<string, string> EventPerSound { get; set; } = new();
    }
}
