﻿using System;
using System.Resources;
using StethoWebAPI.Properties;

namespace StethoWebAPI.Models
{
    public static class DiagnosisData
    {
      
       
        public static string GetDiagnosis(string fileKey)
        {
            try
            {
                string? value = Resources.ResourceManager.GetString(fileKey);
                return string.IsNullOrWhiteSpace(value) ? "N/A" : value;
            }
            catch (MissingManifestResourceException)
            {
                return "N/A";
            }
        }
    }
}
