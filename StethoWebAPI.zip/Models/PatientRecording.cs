﻿namespace StethoWebAPI.Models
{
    public class PatientRecording
    {
        public int Number { get; set; }
        public string Diagnosis { get; set; } = "N/A"; 
        public List<RecordingInfo> Recordings { get; set; } = new();
    }

    public class RecordingInfo
    {
        public string Position { get; set; } = string.Empty;
        public string AudioFile { get; set; } = string.Empty;
        public string Spectrogram { get; set; } = string.Empty;
        public string Event { get; set; } = string.Empty;
    }
}
