﻿using Microsoft.AspNetCore.Mvc;

namespace StethoWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NewPatientSoundController : ControllerBase
    {
        private readonly string dataFolder = Path.Combine(Directory.GetCurrentDirectory(), "DataFiles");

        [HttpPost]
        [ApiExplorerSettings(IgnoreApi = true)] 
        public async Task<IActionResult> UploadSound([FromForm] IFormFile file, [FromForm] string username)
        {
            if (file == null || file.Length == 0 || string.IsNullOrEmpty(username))
                return BadRequest("Date invalide.");

            var fileName = $"{username}_personal.wav";
            var filePath = Path.Combine(dataFolder, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            return Ok(new { audioFile = fileName });
        }
    }
}
