﻿using Microsoft.AspNetCore.Mvc;

namespace StethoWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AiDiagnosticController : ControllerBase
    {
        [HttpGet("{patientNumber}")]
        public IActionResult GetAiDiagnostic(string patientNumber)
        {
            try
            {
                var dataFilesPath = @"C:\Users\laure\OneDrive\Desktop\StethoWebAPI\StethoWebAPI\DataFiles";
                var diagnosisFilePath = @"C:\Users\laure\Downloads\patient_diagnosis.csv"; 

                if (!Directory.Exists(dataFilesPath))
                    return NotFound(" Folderul DataFiles nu a fost găsit.");

                var files = Directory.GetFiles(dataFilesPath, $"{patientNumber}_*.txt");

                if (files.Length == 0)
                    return NotFound($" Nu s-au găsit fișiere pentru pacientul {patientNumber}");

                var predictii = new List<int>();
                var crackleCount = 0;
                var wheezeCount = 0;
                var total = 0;

                foreach (var file in files)
                {
                    var lines = System.IO.File.ReadAllLines(file);
                    foreach (var line in lines)
                    {
                        var parts = line.Trim().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 2 &&
                            int.TryParse(parts[^2], out int crackles) &&
                            int.TryParse(parts[^1], out int wheezes))
                        {
                            int label = (crackles == 1 || wheezes == 1) ? 1 : 0;
                            predictii.Add(label);

                            if (crackles == 1) crackleCount++;
                            if (wheezes == 1) wheezeCount++;
                            total++;
                        }
                    }
                }

               
                var severities = new Dictionary<string, string>();
                if (total > 0)
                {
                    if (crackleCount > 0)
                        severities["crackles"] = $"{(crackleCount * 100 / total):F0}%";
                    if (wheezeCount > 0)
                        severities["wheezes"] = $"{(wheezeCount * 100 / total):F0}%";
                }

                
                string diagnostic = "N/A";
                if (System.IO.File.Exists(diagnosisFilePath))
                {
                    var csvLines = System.IO.File.ReadAllLines(diagnosisFilePath).Skip(1);

                    foreach (var line in csvLines)
                    {
                        var parts = line.Split(',');

                        if (parts.Length >= 2 && parts[0].Trim() == $"P{patientNumber.Trim()}")
                        {
                            diagnostic = parts[1].Trim();
                            break;
                        }
                    }

                }

                return Ok(new
                {
                    message = Evalueaza(predictii),
                    diagnostic = diagnostic, 
                    severity = severities
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Eroare la evaluare: {ex.Message}");
            }
        }

        private string Evalueaza(List<int> predictii)
        {
            if (predictii == null || predictii.Count == 0)
                return "Nu există date suficiente pentru diagnosticare.";

            int total = predictii.Count;
            int ct1 = predictii.Count(x => x == 1);
            int ct0 = total - ct1;

            double confidence = Math.Max(ct1, ct0) * 100.0 / total;

            return ct1 > ct0
                ? $" pacientul este {confidence:F2}% bolnav "
                : $" pacientul este {confidence:F2}% sănătos";
        }
    }
}
