﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StethoWebAPI.Data;
using StethoWebAPI.Helpers;
using StethoWebAPI.Models;

namespace StethoWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class PatientManagementController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PatientManagementController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> CreatePatientWithUser([FromBody] Patient patient)
        {
            if (patient == null)
                return BadRequest("Datele pacientului sunt invalide.");

            
            _context.Patients.Add(patient);

            
            var newUser = new User
            {
                Username = patient.Username, 
                PasswordHash = PasswordHelper.HashPassword("1234"), 
                Role = "pacient"
            };

            _context.Users.Add(newUser);

            await _context.SaveChangesAsync();

            return Ok(new { message = "Pacient și utilizator creat cu succes!" });
        }
    }
}
