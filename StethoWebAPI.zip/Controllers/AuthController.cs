﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StethoWebAPI.Data;
using StethoWebAPI.Helpers;
using StethoWebAPI.Models;

namespace StethoWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Username == user.Username);
            if (existingUser != null)
                return BadRequest("Utilizatorul există deja.");

            
            user.PasswordHash = PasswordHelper.HashPassword(user.PasswordHash);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok("Utilizator înregistrat cu succes!");
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] User login)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == login.Username);
            if (user == null)
                return Unauthorized("Utilizatorul nu există.");

            bool isPasswordValid = PasswordHelper.VerifyPassword(login.PasswordHash, user.PasswordHash);
            if (!isPasswordValid)
                return Unauthorized("Parolă incorectă.");

            return Ok(new
            {
                message = "Autentificare reușită!",
                username = user.Username,
                role = user.Role
            });
        }
    }
}
