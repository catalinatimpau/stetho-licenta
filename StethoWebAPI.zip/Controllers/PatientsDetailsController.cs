﻿using Microsoft.AspNetCore.Mvc;
using StethoWebAPI.Models;
using StethoWebAPI.Properties;
using System.Globalization;

namespace StethoWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientDetailsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetPatients()
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "DataFiles", "patient_details.csv");

            if (!System.IO.File.Exists(filePath))
                return NotFound("Fișierul CSV nu a fost găsit.");

            var patients = new List<Patient>();
            var lines = System.IO.File.ReadAllLines(filePath).Skip(1);

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                var values = line.Split(new[] { ',', ';' }, StringSplitOptions.None);
                if (values.Length < 6) continue;

                try
                {
                    var patient = new Patient
                    {
                        Number = int.Parse(values[0]),
                        Age = (int?)TryParseDouble(values[1]) ?? 0,
                        Sex = values[2],
                        AdultBMI = TryParseDouble(values[3]),
                        ChildWeight = TryParseDouble(values[4]),
                        ChildHeight = TryParseDouble(values[5]),
                        FirstName = "N/A",
                        LastName = "N/A",
                        Diagnosis = Resources.ResourceManager.GetString(values[0]) ?? "N/A",


                        Username = $"PAT{values[0].PadLeft(5, '0')}",
                        Weight = TryParseDouble(values[4]) ?? 0,
                        Height = TryParseDouble(values[5]) ?? 0
                    };

                    patients.Add(patient);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($" Eroare la linia: {line}. Detalii: {ex.Message}");
                }
            }

            return Ok(patients);
        }

       
        private double? TryParseDouble(string input)
        {
            if (string.IsNullOrWhiteSpace(input) || input.Trim().ToUpper() == "NA")
                return null;

            if (double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
                return result;

            return null;
        }
    }
}
