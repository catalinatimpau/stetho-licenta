﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StethoWebAPI.Data;
using StethoWebAPI.Helpers;
using StethoWebAPI.Models;
using System.IO;
using System.Text.RegularExpressions;

namespace StethoWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class PatientsController : ControllerBase
    {
        private readonly string dataFolder = Path.Combine(Directory.GetCurrentDirectory(), "DataFiles");
        private readonly AppDbContext _context;

        public PatientsController(AppDbContext context)
        {
            _context = context;
        }

       
        [HttpGet]
        public ActionResult<List<PatientRecording>> GetAllPatients()
        {
            if (!Directory.Exists(dataFolder))
                return NotFound("DataFiles folder not found.");

            var txtFiles = Directory.GetFiles(dataFolder, "*.txt");

            var grouped = txtFiles
                .GroupBy(file => ExtractPatientNumber(Path.GetFileName(file)))
                .Where(g => g.Key != null)
                .OrderBy(g => g.Key.Value);

            var patients = new List<PatientRecording>();

            foreach (var group in grouped)
            {
                var recordingGroup = new PatientRecording
                {
                    Number = group.Key.Value
                };

                foreach (var txtFile in group)
                {
                    string baseName = Path.GetFileNameWithoutExtension(txtFile);
                    string wavFile = Path.Combine(dataFolder, baseName + ".wav");
                    string pngFile = Path.Combine(dataFolder, baseName + ".png");

                    if (System.IO.File.Exists(wavFile) && System.IO.File.Exists(pngFile))
                    {
                        var recording = new RecordingInfo
                        {
                            Position = ExtractPosition(baseName),
                            AudioFile = Path.GetFileName(wavFile),
                            Spectrogram = Path.GetFileName(pngFile),
                            Event = AnalyzeTxtFile(txtFile)
                        };
                       
                        recordingGroup.Recordings.Add(recording);
                    }
                }

                if (recordingGroup.Recordings.Any())
                    patients.Add(recordingGroup);
            }

            return Ok(patients);
        }

       
        [HttpGet("{id}")]
        public ActionResult<PatientRecording> GetPatientById(int id)
        {
            var allPatients = GetAllPatients().Value;
            if (allPatients == null)
                return NotFound("Nu s-au putut încărca pacienții.");

            var patient = allPatients.FirstOrDefault(p => p.Number == id);
            if (patient == null)
                return NotFound("Pacientul nu a fost găsit.");

            return Ok(patient);
        }
        [HttpGet("database")]
        public ActionResult<List<Patient>> GetPatientsFromDb()
        {
            return _context.Patients.ToList();
        }

       
        [HttpPost]
        public async Task<IActionResult> CreatePatientWithUser([FromBody] Patient patient)
        {
            if (patient == null)
                return BadRequest("Datele pacientului sunt invalide.");

           
            _context.Patients.Add(patient);

           
            var newUser = new User
            {
                Username = patient.Username, 
                PasswordHash = PasswordHelper.HashPassword("1234"), 
                Role = "pacient"
            };

            _context.Users.Add(newUser);

            await _context.SaveChangesAsync();

            return Ok(new { message = "Pacient și utilizator creat cu succes!" });
        }

       
        private int? ExtractPatientNumber(string fileName)
        {
            var match = Regex.Match(fileName, @"^(\d+)_");
            return match.Success && int.TryParse(match.Groups[1].Value, out int number) ? number : null;
        }

        private string ExtractPosition(string fileName)
        {
            var parts = fileName.Split('_');
            return parts.Length >= 3 ? parts[2] : "Unknown";
        }

        private string AnalyzeTxtFile(string path)
        {
            int crackles = 0, wheezes = 0;

            foreach (var line in System.IO.File.ReadLines(path))
            {
                var parts = line.Split('\t');
                if (parts.Length >= 4)
                {
                    if (parts[2].Trim() == "1") crackles++;
                    if (parts[3].Trim() == "1") wheezes++;
                }
            }

            return (crackles, wheezes) switch
            {
                (0, 0) => "none",
                ( > 0, 0) => "crackles",
                (0, > 0) => "wheezes",
                _ => "both"
            };
        }
    }
}
